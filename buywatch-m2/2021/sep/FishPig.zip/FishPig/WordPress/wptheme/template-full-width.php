<?php
/**
 * Template Name: Full Width (1 Column)
 * Template Post Type: post, page
 */
// phpcs:ignoreFile -- this file is a WordPress theme file and will not run in Magento
get_template_part('index');
