<?php
/*
 *
 */
// phpcs:ignoreFile -- this file is a WordPress theme file and will not run in Magento
if (is_active_sidebar('sidebar-1')) {
	dynamic_sidebar('sidebar-1');
}
else if (is_active_sidebar('sidebar-2')) {
	dynamic_sidebar('sidebar-2');	
}
