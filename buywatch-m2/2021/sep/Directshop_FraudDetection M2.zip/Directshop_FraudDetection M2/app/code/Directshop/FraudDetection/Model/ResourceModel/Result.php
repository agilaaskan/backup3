<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\FraudDetection\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;

class Result extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('frauddetection_data', 'entity_id');
    }
}
