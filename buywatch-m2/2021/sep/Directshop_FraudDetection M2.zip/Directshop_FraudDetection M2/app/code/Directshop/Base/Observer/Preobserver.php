<?php 
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\Base\Observer;
 
use \Psr\Log\LoggerInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
 
 
class Preobserver implements ObserverInterface
{
    
    protected $logger;
	protected $_session;	
	/**
     * @var \Magento\Store\Model\ScopeInterface    
	*/
    protected $scopeConfig;
	protected $feed;
 
   
    public function __construct(LoggerInterface $logger, \Magento\Backend\Model\Auth\Session $authSession, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Directshop\Base\Model\Notificationfeed $feed)
    {
        $this->logger = $logger;
		$this->_session = $authSession;
		$this->_scopeConfig    = $scopeConfig;
		$this->_feed    = $feed;
		
    }
 
    public function execute(Observer $observer)
    {
	
		 if ($this->_session->isLoggedIn() && $this->_scopeConfig->getValue(\Directshop\Base\Model\Notificationfeed::DSBASE_XML_NOTIFICATION_ENABLED)) 
        {
			 $this->_feed->checkUpdate();			 
			 //$this->logger->warn('CHECKING');
            //$feedModel  = Mage::getModel('dsbase/notificationfeed');
            //$feedModel->checkUpdate();
        }				
        
    }
}
?>