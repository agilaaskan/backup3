<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
 
namespace Directshop\FraudDetection\Model;
class Stats extends \Magento\Framework\Model\AbstractModel 
{
    public function __construct(
    \Magento\Framework\Model\Context $context,
    \Magento\Framework\Registry $registry,
    \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
    \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
    array $data = []        
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
        
        
    }
    protected function _construct()
    {
        $this->_init('Directshop\FraudDetection\Model\ResourceModel\Stats');
    }
}
