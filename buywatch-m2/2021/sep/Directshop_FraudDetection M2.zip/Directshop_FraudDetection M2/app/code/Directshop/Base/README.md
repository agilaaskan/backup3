Magento 2 Base by Directshop
========================================

####Support
    v1.0.* - Magento 2.1.*

####Installation
    1. Download the archive.
    2. Make sure to create the directory structure in your Magento - 'Magento_Root/app/code/Directshop/Base'.
    3. Unzip the content of archive to directory 'Magento_Root/app/code/Directshop/Base'.
       (use command 'unzip ArchiveName.zip -d path_to/app/code/Directshop/Base').
    4. Run the command 'php bin/magento module:enable Directshop_Base' in Magento root.
       If you need to clear static content use 'php bin/magento module:enable --clear-static-content Directshop_Base'.
    5. Run the command 'php bin/magento setup:upgrade' in Magento root.
    6. Run the command 'php bin/magento setup:di:compile' if you have a single website and store, 
       or 'php bin/magento setup:di:compile-multi-tenant' if you have multiple ones.
    7. Clear cache: 'php bin/magento cache:clean', 'php bin/magento cache:flush'.
    8. Deploy static content: 'php bin/magento setup:static-content:deploy'.
