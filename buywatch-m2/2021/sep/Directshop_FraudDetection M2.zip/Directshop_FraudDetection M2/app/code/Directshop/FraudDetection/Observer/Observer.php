<?php 
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\FraudDetection\Observer;

use Magento\Framework\Event\ObserverInterface; 

class Observer implements ObserverInterface { 

     /**
     * @var \Directshop\FraudDetection\Helper\Data
     */
   // protected $fraudDetectionHelper;

    public function __construct(
       // \Directshop\FraudDetection\Helper\Data $fraudDetectionHelper
    ) {
        //$this->fraudDetectionHelper = $fraudDetectionHelper;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
    	$order = $observer->getOrder();
		echo "<pre>";
		print_r($order->getId());die("in obs");
    	if ($res = $order->getFraudDataTemp())
    	{
    		if ($order->getId())
    		{
    			$this->fraudDetectionHelper->saveFraudData($res, $order);
    			$order->unsFraudDataTemp();	
    		}
    	}
    }

}