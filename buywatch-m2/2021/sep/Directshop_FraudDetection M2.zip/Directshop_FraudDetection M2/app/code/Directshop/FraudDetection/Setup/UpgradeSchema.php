<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\FraudDetection\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;

 class UpgradeSchema implements UpgradeSchemaInterface
 {

   /**
    * {@inheritdoc}
    * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
   */
   public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
   {

       $installer = $setup;
       $installer->startSetup();

       $installer->getConnection()->addColumn(
            $installer->getTable('sales_order_grid'),
            'fraud_score',                            
                [
                    'type'     => Table::TYPE_FLOAT, 
					'nullable' => true,
                    'scale' => '2',
                    'precision' => '8',
					'comment'  => 'Fraud Score',
                ]
        );

       $setup->endSetup();
  }
}