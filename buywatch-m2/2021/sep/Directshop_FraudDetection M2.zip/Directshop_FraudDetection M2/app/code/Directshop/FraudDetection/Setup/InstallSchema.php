<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */

namespace Directshop\FraudDetection\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 * @package Directshop\FraudDetection\Setup
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        
        $installer->startSetup();
        
        /**
         * Create table 'frauddetection_stats'
         */
        $table = $installer->getConnection()
            ->newTable($installer->getTable('frauddetection_stats'))
            ->addColumn(
                'code',
                Table::TYPE_TEXT,
                32,
                [
                    'nullable' => false,
                    'primary' => true,
                ],
                'null'
            )
            ->addColumn(
                'value',
                Table::TYPE_TEXT,
                32,
                [
                    'default' => '0',
                    'nullable' => false,
                ],
                'null'
            )
            ->setComment('Fraud Detection Stats');
        $installer->getConnection()->createTable($table);
		
		
		/**
         * Create table 'frauddetection_data'
         */
        $table = $installer->getConnection()
            ->newTable($installer->getTable('frauddetection_data'))
            ->addColumn(
                'entity_id',
                Table::TYPE_INTEGER,
                10,
                [
                    'nullable' => false,
                    'precision' => '10',
                    'auto_increment' => true,
                    'primary' => true,
                ],
                'null'
            )
            ->addColumn(
                'order_id',
                Table::TYPE_INTEGER,
                10,
                [
                    'nullable' => false,
                    'precision' => '10',
                ],
                'null'
            )
            ->addColumn(
                'fraud_score',
                Table::TYPE_FLOAT,
                '8,2',
                [
                    'nullable' => true,
                    'scale' => '2',
                    'precision' => '8',
                ],
                'null'
            )
            ->addColumn(
                'fraud_data',
                Table::TYPE_TEXT,
                null,
                [
                    'nullable' => true,
                ],
                'null'
            )
            ->addColumn(
                'sent_data',
                Table::TYPE_TEXT,
                null,
                [
                    'nullable' => true,
                ],
                'null'
            )
			->addIndex(
               $installer->getIdxName(
                   'frauddetection_data', ['order_id']
               ),
               ['order_id']
	        )->setComment('Fraud Detection Stats');
        $installer->getConnection()->createTable($table);
		
		
        
        
        $installer->endSetup();
    }
}
