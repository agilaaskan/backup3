<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\FraudDetection\Block\Adminhtml\System\Config\Form\Field;

class Ipexceptions extends \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{
   

    /**
     * Prepare to render.
     *
     * @return void
     */
    protected function _prepareToRender()
    {
        $this->addColumn('ipaddress',
            [
                'label' => __('IP Address')
                
            ]
        );

        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add Exception');
    }

   
}