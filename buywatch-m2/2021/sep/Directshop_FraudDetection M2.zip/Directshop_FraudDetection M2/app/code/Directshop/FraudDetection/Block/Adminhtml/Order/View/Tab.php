<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\FraudDetection\Block\Adminhtml\Order\View;

use Magento\Backend\Block\Template;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Directshop\FraudDetection\Model\ResultFactory;
use Magento\Customer\Model\CustomerFactory;


class Tab extends \Magento\Backend\Block\Template implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
	
	 /**
     * @var string
     */
    protected $_template = 'order/view/tab.phtml';

    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;
	
	/**
     * @var CheckContext
     */
    private $context;

    /**
     * @var \Directshop\FraudDetection\Model\ResultFactory
     */
    protected $fraudDetectionResultFactory;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $customerCustomerFactory;

    public function __construct(
	    \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Helper\Admin $adminHelper,     
        \Directshop\FraudDetection\Model\ResultFactory $fraudDetectionResultFactory,
        \Magento\Customer\Model\CustomerFactory $customerCustomerFactory,
		array $data = []
    ) { 
	    $this->context = $context;
        $this->registry = $registry;
        $this->fraudDetectionResultFactory = $fraudDetectionResultFactory;
        $this->customerCustomerFactory = $customerCustomerFactory;
		parent::__construct($context , $data);
		$this->adminHelper = $adminHelper;
    }
   
		
    /**
     * Retrieve order model instance
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->registry->registry('current_order');
    }
    
    public function getFraudResult()
    {
    	$order = $this->getOrder();
		$result = $this->fraudDetectionResultFactory->create()->loadByOrderId($order->getId());
		$res = @unserialize(utf8_decode($result->getFraudData()));
		return $res;
    }
    
    public function getCustomer()
    {
    	$customer = $this->customerCustomerFactory->create()->load($this->getOrder()->getCustomerId());
    	return $customer;
    }

    /**
     * ######################## TAB settings #################################
     */
	 
	 /**
     * Get Tab Url
     *
     * @return string
     */
    public function getTabUrl()
    {
        return $this->getUrl('frauddetection/*/tab', ['_current' => true]);
    }
	/**
     * Get Tab Class
     *
     * @return string
     */
    public function getTabClass()
    {
        return 'ajax only';
    } 
	 
    public function getTabLabel()
    {
        return __('Fraud Detection');
    }

    public function getTabTitle()
    {
        return __('Fraud Detection');
    }

    public function canShowTab()
    {
        return true;
    }

    public function isHidden()
    {
        return false;
    }
}