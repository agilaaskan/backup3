<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */

namespace Directshop\Base\Model\Source;

/**
 * Class Frequency
 * @package Directshop\Base\Model\Source
 */
class Frequency implements \Magento\Framework\Option\ArrayInterface
{
    /**#@+
     * "Frequency" types
     */
    const HOUR_1 = 1;
    const HOUR_2 = 2;
    const HOUR_6 = 6;
	const HOUR_12 = 12;
	const HOUR_24 = 24;
    /**#@-*/

    /**
     * @var null|array
     */
    private $optionArray;

    /**
     * Get option array
     *
     * @return array
     */
    public function getOptions()
    {
        return [
            self::HOUR_1 => __('1 Hour'),
            self::HOUR_2 => __('2 HOurs'),
            self::HOUR_6 => __('6 Hours'),
			self::HOUR_12 => __('12 Hours'),
			self::HOUR_24 => __('24 Hours'),
        ];
    }

    /**
     * @inheritdoc
     */
    public function toOptionArray()
    {
        if (!$this->optionArray) {
            $this->optionArray = [];
            foreach ($this->getOptions() as $value => $label) {
                $this->optionArray[] = ['value' => $value, 'label' => $label];
            }
        }
        return $this->optionArray;
    }

    /**
     * Get label by value
     *
     * @param int $value
     * @return null|\Magento\Framework\Phrase
     */
    public function getOptionLabelByValue($value)
    {
        $options = $this->getOptions();
        if (array_key_exists($value, $options)) {
            return $options[$value];
        }
        return null;
    }
}
