<?php 
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\FraudDetection\Observer;

use Magento\Framework\Event\ObserverInterface; 

class CallMaxmind implements ObserverInterface { 

    /**
     * @var \Directshop\FraudDetection\Helper\Data
     */
    protected $fraudDetectionHelper;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
	
	/**
     * Order Model
     *
     * @var \Magento\Sales\Model\Order $order
     */
    protected $order;
	

    public function __construct(
        \Directshop\FraudDetection\Helper\Data $fraudDetectionHelper,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		 \Magento\Sales\Model\Order $order
    ) {
        $this->fraudDetectionHelper = $fraudDetectionHelper;
        $this->scopeConfig = $scopeConfig;
		$this->order = $order;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
	{

                $order = $observer->getEvent()->getOrder(); 
		$res = $this->fraudDetectionHelper->normaliseMaxMindResponse($this->fraudDetectionHelper->getMaxMindResponse($order));
		// don't save the order if there's a fatal error
                
		if (empty($res['err']) || !in_array($res['err'], \Directshop\FraudDetection\Model\Result::$fatalErrors))
		{
			
			$this->fraudDetectionHelper->saveFraudData($res, $order);
			$order->setFraudDataTemp($res);
			
			if ($this->scopeConfig->getValue('directshop_fraud/general/holdwhenflagged', \Magento\Store\Model\ScopeInterface::SCOPE_STORE) && 
				$res['ourscore'] >= $this->scopeConfig->getValue('directshop_fraud/general/threshold', \Magento\Store\Model\ScopeInterface::SCOPE_STORE) && 
				$order->canHold())
			{
                                $orderState = \Magento\Sales\Model\Order::STATE_HOLDED;
                                $order->setState($orderState)->setStatus(\Magento\Sales\Model\Order::STATE_HOLDED);
                                $order->save();
				$this->fraudDetectionHelper->sendHoldEmail($order, $res);
			}
		}
	}
}
