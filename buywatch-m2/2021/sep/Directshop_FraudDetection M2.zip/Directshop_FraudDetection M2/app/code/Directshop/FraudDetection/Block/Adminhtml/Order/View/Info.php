<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
 
namespace Directshop\FraudDetection\Block\Adminhtml\Order\View;

class Info extends \Magento\Backend\Block\Template
{
/**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    private $urlBuilder;
	
	/**
     * @var \Directshop\FraudDetection\Model\ResultFactory
     */
    protected $fraudDetectionResultFactory;
	
	/**
     * @var \Directshop\FraudDetection\Helper\Data
     */
    protected $fraudDetectionHelper;
	
	 /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
	

    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
		\Directshop\FraudDetection\Model\ResultFactory $fraudDetectionResultFactory,
	     \Directshop\FraudDetection\Helper\Data $fraudDetectionHelper,
		 \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,       
        array $data = []
    )
    {
        $this->urlBuilder = $context->getUrlBuilder();
        $this->coreRegistry = $registry;
		$this->fraudDetectionResultFactory = $fraudDetectionResultFactory;
		$this->fraudDetectionHelper = $fraudDetectionHelper;
		$this->scopeConfig = $scopeConfig;       
        parent::__construct($context, $data);
    }

    /**
     * Retrieve order
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->coreRegistry->registry('current_order');
    } 
	
	
	 public function getFraudResult()
    {
    	$order = $this->getOrder();
		$result = $this->fraudDetectionResultFactory->create()->loadByOrderId($order->getId());
		$res['queriesRemaining'] = '';
		$res['ourscore'] = '';	
		$res = @unserialize(utf8_decode($result->getFraudData()));				
		$payment = $order->getPayment();
		if (empty($res))
		{
			if ($payment->getId())
			{
				$res = $this->fraudDetectionHelper->normaliseMaxMindResponse($this->fraudDetectionHelper->getMaxMindResponse($payment));
				if (empty($res['err']) || !in_array($res['err'], \Directshop\FraudDetection\Model\Result::$fatalErrors))
				{
					$this->fraudDetectionHelper->saveFraudData($res, $order);
				}
			}
			else
			{
				$res = array(
					'errmsg' => 'This order has no payment data.'
				);
			}
		}
		
	
		
		$output = array();
		$output['result'] = $output['queriesRemaining'] = '';
		
		if (isset($res['err']) && (in_array($res['err'], \Directshop\FraudDetection\Model\Result::$fatalErrors) || $res['ourscore'] == -1))
		{
			$output['result'] = isset($res['errmsg']) ? $res['errmsg'] : $res['err'];
		}
		else
		{
			$score = 0;
			if (isset($res['ourscore']))
			{
				$score = $res['ourscore'];
			}
			
			$colour = "auto";
			if ($res['ourscore'] >= $this->scopeConfig->getValue('directshop_fraud/general/threshold', \Magento\Store\Model\ScopeInterface::SCOPE_STORE))
			{
				$colour = "red";
			}
			
			$per = "N/A";
			if(isset($score) && !empty($score)){						       
					 $riskScore = number_format($score, 2);								 
					 if($riskScore >= 0.1 && $riskScore <=4.99 ) {
							$per = "90%";
						} else if($riskScore >= 5 && $riskScore <=9.99 ) {
							$per =  "5%";
						} else if($riskScore >= 10 && $riskScore <=29.99 ) {
							$per =  "3%";
						} else if($riskScore >= 30 && $riskScore <=99.99 ) {
							$per =  "2%";
						}						   
			 }			
			 
			$output['result'] = "<table class='admin__table-secondary order-information-table' cellspacing='0'><tbody><tr><th class='label'>Risk Score Estimate (%)</th><td><span style='color:$colour;font-weight:bold;display: block;margin-top: 5px;'>$score%  (Approximately $per of all orders fall in this range)</span></td></tr></tbody></table>";
			
		
		}
	    $output['queriesRemaining'] = $res['queriesRemaining']; 		
		return $output;	
		
    } 
   
}