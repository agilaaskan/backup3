<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\FraudDetection\Model;
class Result extends \Magento\Framework\Model\AbstractModel 
{
    static $fatalErrors = array('INVALID_LICENSE_KEY', 'MAX_REQUESTS_PER_LICENSE','IP_REQUIRED','LICENSE_REQUIRED','COUNTRY_REQUIRED','MAX_REQUESTS_REACHED','SYSTEM_ERROR','IP_NOT_FOUND', 'FATAL_ERROR');
   
    protected $_order;

    public function __construct(
    \Magento\Framework\Model\Context $context,
    \Magento\Framework\Registry $registry,
    \Magento\Sales\Api\Data\OrderInterface $order ,
    \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
    \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
    array $data = []        
    ) {
        $this->_order = $order;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
        
        
    }

    protected function _construct()
    {
        $this->_init('Directshop\FraudDetection\Model\ResourceModel\Result');
    }
    function loadByOrderId($orderId)
    {
    	$this->load($orderId,'order_id');
    	return $this;
    }
}
