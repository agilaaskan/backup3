<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
namespace Directshop\Base\Model;


/**
 * AdminNotification Feed model
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @api
 * @since 100.0.2
 */

class Notificationfeed extends \Magento\AdminNotification\Model\Feed
{
	const DSBASE_XML_NOTIFICATION_ENABLED  = 'directshop_base/notifications/notification_enabled';
	const DSBASE_XML_USE_HTTPS_PATH    = 'directshop_base/notifications/notification_use_https';
    const DSBASE_XML_FEED_URL_PATH     = 'directshop_base/notifications/feed_url';
    const DSBASE_XML_FREQUENCY_PATH    = 'directshop_base/notifications/notification_frequency';
    const DSBASE_XML_LAST_UPDATE_PATH  = 'directshop_base/notifications/last_update';
    
		 
	 /**
     * Retrieve Update Frequency
     *
     * @return int
     */
    public function getFrequency()
    {
        return $this->_backendConfig->getValue(self::DSBASE_XML_FREQUENCY_PATH) * 3600;
    }
    
    
	/**
     * Retrieve feed url
     *
     * @return string
     */
	 
	 public function getFeedUrl()
    {
        $httpPath = $this->_backendConfig->isSetFlag(self::DSBASE_XML_USE_HTTPS_PATH) ? 'https://' : 'http://';
        if ($this->_feedUrl === null) {
            $this->_feedUrl = $httpPath . $this->_backendConfig->getValue(self::DSBASE_XML_FEED_URL_PATH);
        }
        return $this->_feedUrl;
    }   

    /**
     * Retrieve Last update time
     *
     * @return int
     */
	 
	 public function getLastUpdate()
    {
        return $this->_cacheManager->load('directshop_dsbase_notifications_lastcheck');
    }
	

    /**
     * Set last update time (now)
     *
     * @return Mage_AdminNotification_Model_Feed
     */
	  public function setLastUpdate()
		{
			$this->_cacheManager->save(time(), 'directshop_dsbase_notifications_lastcheck');
			return $this;
		}  
			
		 
}