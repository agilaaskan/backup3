<?php
/**
 *
 * @category   Directshop
 * @package    Directshop_FraudDetection
 * @author     Vipul Mishra
 * @copyright  Copyright (c) 20018 Directshop Pty Ltd. (http://directshop.com.au)
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Directshop_Base',
    __DIR__
);
