<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2021 Amasty (https://www.amasty.com)
 * @package Amasty_Checkout
 */


namespace Amasty\Checkout\Block\Adminhtml\Field\Edit\Group;

use Magento\Framework\Data\Form\Element\AbstractElement;

/**
 * Class Row
 */
class Row extends AbstractElement
{
}
