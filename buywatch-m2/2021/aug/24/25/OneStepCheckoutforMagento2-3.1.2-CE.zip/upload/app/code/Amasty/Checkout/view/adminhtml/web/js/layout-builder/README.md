Install Node.js
https://nodejs.org/en/download/

For development:
1. Go to project root folder
2. run `npm install` 
3. run `npm run dev`

For production:
1. Go to project root folder
2. run `npm install` 
3. run `npm run build`
